#!/usr/bin/env python
# coding: utf-8

# In[4]:


import pandas as pd

df_static = pd.read_csv('E:/Research/research/Dataset/TUANDROMD.csv')
df_dynamic = pd.read_csv('E:/Research/research/Dataset/CICMalDroid 2020.csv')

print(df_static.head())
print(df_dynamic.head())


# In[5]:


import pandas as pd

# Load TUANDROMD dataset
tuandromd_df = pd.read_csv("E:/Research/research/Dataset/TUANDROMD.csv")

# Load CICMalDroid dataset
cicmaldroid_df = pd.read_csv("E:/Research/research/Dataset/CICMalDroid 2020.csv")


# In[ ]:


print(tuandromd_df.columns)
print(tuandromd_df['Label'].unique())  # replace 'label' with actual label column if different

print(cicmaldroid_df.columns)
print(cicmaldroid_df['Class'].unique())  # replace 'Class' with actual label column if different


# In[6]:


# Drop rows with missing labels
tuandromd_df = tuandromd_df.dropna(subset=['Label'])

# Ensure integer type
tuandromd_df['Label'] = tuandromd_df['Label'].astype(int)

# Rename for consistency
tuandromd_df['binary_label'] = tuandromd_df['Label']  # Already binary


# In[7]:


# Drop rows with missing labels (in-place safe)
tuandromd_df = tuandromd_df.dropna(subset=['Label']).copy()

# Convert to integer safely
tuandromd_df.loc[:, 'Label'] = tuandromd_df['Label'].astype(int)

# Create binary label column
tuandromd_df.loc[:, 'binary_label'] = tuandromd_df['Label']


# In[8]:


# TUANDROMD
X_static = tuandromd_df.drop(columns=['Label', 'binary_label'])
y_static = tuandromd_df['binary_label']

# CICMalDroid
X_dynamic = cicmaldroid_df.drop(columns=['Class'])
y_dynamic = cicmaldroid_df['Class']


# In[9]:


# Convert multiclass to binary: 1 for malware, 0 for goodware
y_dynamic_binary = y_dynamic.apply(lambda x: 1 if x != 0 else 0)


# In[10]:


from sklearn.preprocessing import StandardScaler

# Static
scaler_static = StandardScaler()
X_static_scaled = scaler_static.fit_transform(X_static)

# Dynamic
scaler_dynamic = StandardScaler()
X_dynamic_scaled = scaler_dynamic.fit_transform(X_dynamic)


# In[11]:


from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, accuracy_score

# Static model (TUANDROMD)
X_train_static, X_test_static, y_train_static, y_test_static = train_test_split(X_static_scaled, y_static, test_size=0.2, random_state=42)
static_clf = RandomForestClassifier(random_state=42)
static_clf.fit(X_train_static, y_train_static)
y_pred_static = static_clf.predict(X_test_static)

# Dynamic model (CICMalDroid)
X_train_dynamic, X_test_dynamic, y_train_dynamic, y_test_dynamic = train_test_split(X_dynamic_scaled, y_dynamic_binary, test_size=0.2, random_state=42)
dynamic_clf = RandomForestClassifier(random_state=42)
dynamic_clf.fit(X_train_dynamic, y_train_dynamic)
y_pred_dynamic = dynamic_clf.predict(X_test_dynamic)

# Evaluate both
print("Static Model Report (TUANDROMD):")
print(classification_report(y_test_static, y_pred_static))

print("Dynamic Model Report (CICMalDroid):")
print(classification_report(y_test_dynamic, y_pred_dynamic))


# In[12]:


print("Static test distribution:", y_test_static.value_counts())
print("Dynamic test distribution:", y_test_dynamic.value_counts())


# In[13]:


train_test_split(X_dynamic_scaled, y_dynamic_binary, test_size=0.2, random_state=42, stratify=y_dynamic_binary)


# 

# In[23]:


from sklearn.model_selection import GridSearchCV

param_grid = {
    'n_estimators': [100, 200],
    'max_depth': [None, 10, 20],
    'min_samples_split': [2, 5, 10],
    'min_samples_leaf': [1, 2, 4]
}

grid_search_static = GridSearchCV(RandomForestClassifier(random_state=42), param_grid, cv=3, n_jobs=-1, scoring='f1_weighted')
grid_search_static.fit(X_train_static, y_train_static)

best_static_model = grid_search_static.best_estimator_


# In[14]:


from sklearn.model_selection import cross_val_score

scores = cross_val_score(static_clf, X_static_scaled, y_static, cv=5, scoring='f1_weighted')
print("Cross-validation F1 score (static):", scores.mean())


# In[16]:


import matplotlib.pyplot as plt

importances = static_clf.feature_importances_
plt.barh(range(len(importances)), importances)
plt.show()


# In[21]:


from sklearn.feature_selection import SelectFromModel
selector = SelectFromModel(static_clf, threshold='median')
X_train_selected = selector.fit_transform(X_train_static, y_train_static)


# In[22]:


from imblearn.over_sampling import SMOTE
smote = SMOTE(random_state=42)
X_resampled, y_resampled = smote.fit_resample(X_train_static, y_train_static)


# In[ ]:





# In[24]:


from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report

# Retrain with the best C value
best_static_clf = LogisticRegression(penalty='l2', C=1, solver='liblinear', random_state=42)
best_static_clf.fit(X_train_static, y_train_static)

# Predict on the test set
y_pred_static_best = best_static_clf.predict(X_test_static)

# Evaluate
print("Tuned Static Model Report (Logistic Regression with C=1):")
print(classification_report(y_test_static, y_pred_static_best))


# In[25]:


from sklearn.feature_selection import SelectFromModel

selector = SelectFromModel(best_static_clf, threshold='median')
X_train_static_reduced = selector.fit_transform(X_train_static, y_train_static)
X_test_static_reduced = selector.transform(X_test_static)

# Re-train and evaluate
reduced_model = LogisticRegression(C=1, penalty='l2', solver='liblinear', random_state=42)
reduced_model.fit(X_train_static_reduced, y_train_static)
print(classification_report(y_test_static, reduced_model.predict(X_test_static_reduced)))


# In[26]:


from sklearn.model_selection import cross_val_score
cv_scores = cross_val_score(best_static_clf, X_static_scaled, y_static, cv=5, scoring='f1_weighted')
print("Cross-validated F1 score:", cv_scores.mean())


# In[27]:


print(y_static.value_counts())


# In[28]:


balanced_clf = LogisticRegression(C=1, penalty='l2', solver='liblinear', class_weight='balanced', random_state=42)
balanced_clf.fit(X_train_static, y_train_static)
print("Balanced Logistic Regression Report:")
print(classification_report(y_test_static, balanced_clf.predict(X_test_static)))


# In[29]:


from imblearn.over_sampling import SMOTE
sm = SMOTE(random_state=42)
X_resampled, y_resampled = sm.fit_resample(X_train_static, y_train_static)

smote_clf = LogisticRegression(C=1, penalty='l2', solver='liblinear', random_state=42)
smote_clf.fit(X_resampled, y_resampled)
print("SMOTE Logistic Regression Report:")
print(classification_report(y_test_static, smote_clf.predict(X_test_static)))


# In[30]:


from sklearn.feature_selection import SelectFromModel
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report

# Train the logistic regression model
log_clf = LogisticRegression(C=1, penalty='l2', solver='liblinear', random_state=42)
log_clf.fit(X_train_static, y_train_static)

# Feature selection
selector = SelectFromModel(log_clf, threshold='median', prefit=True)
X_train_static_reduced = selector.transform(X_train_static)
X_test_static_reduced = selector.transform(X_test_static)

# Retrain on reduced features
reduced_clf = LogisticRegression(C=1, penalty='l2', solver='liblinear', random_state=42)
reduced_clf.fit(X_train_static_reduced, y_train_static)

# Evaluate
y_pred_reduced = reduced_clf.predict(X_test_static_reduced)
print("Reduced Feature Model Report (Logistic Regression):")
print(classification_report(y_test_static, y_pred_reduced))


# In[31]:


from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler

# (Optional) scale again if necessary
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train_static)
X_test_scaled = scaler.transform(X_test_static)

# Apply PCA (retain 95% of variance)
pca = PCA(n_components=0.95, random_state=42)
X_train_pca = pca.fit_transform(X_train_scaled)
X_test_pca = pca.transform(X_test_scaled)

# Train logistic regression on PCA-reduced data
pca_clf = LogisticRegression(C=1, penalty='l2', solver='liblinear', random_state=42)
pca_clf.fit(X_train_pca, y_train_static)

# Evaluate
y_pred_pca = pca_clf.predict(X_test_pca)
print("PCA-Reduced Model Report:")
print(classification_report(y_test_static, y_pred_pca))


# In[33]:


from sklearn.decomposition import PCA
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report
from sklearn.preprocessing import StandardScaler

# Step 1: Scale data
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train_static)
X_test_scaled = scaler.transform(X_test_static)

# Step 2: Apply PCA
pca = PCA(n_components=0.95, random_state=42)
X_train_pca = pca.fit_transform(X_train_scaled)
X_test_pca = pca.transform(X_test_scaled)

# Step 3: Train with class_weight='balanced'
pca_balanced_clf = LogisticRegression(C=1, penalty='l2', solver='liblinear', class_weight='balanced', random_state=42)
pca_balanced_clf.fit(X_train_pca, y_train_static)

# Step 4: Evaluate
y_pred_pca_bal = pca_balanced_clf.predict(X_test_pca)
print("PCA + Balanced Logistic Regression Report:")
print(classification_report(y_test_static, y_pred_pca_bal))


# In[34]:


import pandas as pd

# Example: align columns manually if needed
# Select columns intersection or union for both datasets
common_columns = list(set(tuandromd_df.columns).intersection(set(cicmaldroid_df.columns)))

# Optionally select only common columns
tuandromd_subset = tuandromd_df[common_columns]
cicmaldroid_subset = cicmaldroid_df[common_columns]

# Concatenate vertically
combined_df = pd.concat([tuandromd_subset, cicmaldroid_subset], axis=0, ignore_index=True)

print(combined_df.shape)


# In[35]:


tuandromd_renamed = tuandromd_df.add_prefix('static_')
cicmaldroid_renamed = cicmaldroid_df.add_prefix('dynamic_')

# Concatenate horizontally, but rows may not align properly if no key
# So be cautious: will create a large DataFrame with no guaranteed row correspondence
combined_side_by_side = pd.concat([tuandromd_renamed.reset_index(drop=True), cicmaldroid_renamed.reset_index(drop=True)], axis=1)

print(combined_side_by_side.shape)


# In[36]:


from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier, VotingClassifier
from sklearn.metrics import roc_auc_score, roc_curve, precision_recall_curve
import matplotlib.pyplot as plt
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix

def plot_roc_curve(model, X_test, y_test, label):
    y_probs = model.predict_proba(X_test)[:, 1]
    fpr, tpr, _ = roc_curve(y_test, y_probs)
    auc_score = roc_auc_score(y_test, y_probs)
    plt.plot(fpr, tpr, label=f"{label} (AUC = {auc_score:.2f})")

def build_pipeline(model):
    return Pipeline([
        ('imputer', SimpleImputer(strategy='median')),
        ('scaler', StandardScaler()),
        ('classifier', model)
    ])


# In[37]:


print(tuandromd_df.columns)


# In[39]:


X = tuandromd_df.drop('binary_label', axis=1)
y = tuandromd_df['binary_label']


# In[40]:


print(tuandromd_df['Label'].value_counts())


# In[41]:


import matplotlib.pyplot as plt

tuandromd_df['Label'].value_counts().plot(kind='bar', figsize=(12, 5), color='skyblue')
plt.title('Class Distribution in TUANDROMD - Label Column')
plt.xlabel('Class Label')
plt.ylabel('Number of Samples')
plt.xticks(rotation=45, ha='right')
plt.tight_layout()
plt.show()


# In[45]:


print(cicmaldroid_df.columns)


# In[ ]:





# In[49]:


print(cicmaldroid_df['Class'].value_counts())


# In[50]:


import matplotlib.pyplot as plt

cicmaldroid_df['Class'].value_counts().plot(kind='bar', figsize=(12, 5), color='salmon')
plt.title('Class Distribution in CICMalDroid - Class Column')
plt.xlabel('Class Label')
plt.ylabel('Number of Samples')
plt.xticks(rotation=45, ha='right')
plt.tight_layout()
plt.show()


# In[51]:


# Convert multiclass Class column to binary label: 0 = goodware, 1 = malware
cicmaldroid_df['Label'] = cicmaldroid_df['Class'].apply(lambda x: 0 if x == 1 else 1)

# Optional: Check the distribution of the new binary label
print(cicmaldroid_df['Label'].value_counts())


# In[52]:


print(tuandromd_df['Label'].value_counts())


# In[53]:


import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, confusion_matrix

# Separate features and labels
tuan_features = tuandromd_df.drop('Label', axis=1)
tuan_labels = tuandromd_df['Label']

cicm_features = cicmaldroid_df.drop('Label', axis=1)
cicm_labels = cicmaldroid_df['Label']

# Standardize features independently
scaler = StandardScaler()
tuan_scaled = scaler.fit_transform(tuan_features)
cicm_scaled = scaler.fit_transform(cicm_features)

tuan_df_scaled = pd.DataFrame(tuan_scaled, columns=tuan_features.columns)
tuan_df_scaled['Label'] = tuan_labels.values

cicm_df_scaled = pd.DataFrame(cicm_scaled, columns=cicm_features.columns)
cicm_df_scaled['Label'] = cicm_labels.values

# Align features: fill missing columns with zeros
tuan_cols = set(tuan_df_scaled.columns) - {'Label'}
cicm_cols = set(cicm_df_scaled.columns) - {'Label'}

# Columns only in one dataset
tuan_only = tuan_cols - cicm_cols
cicm_only = cicm_cols - tuan_cols

# Define full feature set
all_features = sorted(list(tuan_cols.union(cicm_cols)))

# Align both DataFrames to have the same columns
tuan_df_scaled = tuan_df_scaled.reindex(columns=all_features + ['Label'], fill_value=0)
cicm_df_scaled = cicm_df_scaled.reindex(columns=all_features + ['Label'], fill_value=0)


#Merge both datasets
hybrid_df = pd.concat([tuan_df_scaled, cicm_df_scaled], ignore_index=True)

#Train/Test split
X = hybrid_df.drop('Label', axis=1)
y = hybrid_df['Label']
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, stratify=y, random_state=42)

#Train a model (Random Forest for example)
clf = RandomForestClassifier(n_estimators=100, random_state=42)
clf.fit(X_train, y_train)

#Evaluate
y_pred = clf.predict(X_test)
print("Classification Report:\n", classification_report(y_test, y_pred))
print("Confusion Matrix:\n", confusion_matrix(y_test, y_pred))


# In[54]:


# Keep only common features
common_features = list(tuan_cols.intersection(cicm_cols))
tuan_df_scaled = tuan_df_scaled[common_features + ['Label']]
cicm_df_scaled = cicm_df_scaled[common_features + ['Label']]


# In[55]:


from sklearn.utils import resample

# Combine data
hybrid_df = pd.concat([tuan_df_scaled, cicm_df_scaled], ignore_index=True)

# Split by class
malware = hybrid_df[hybrid_df['Label'] == 1]
goodware = hybrid_df[hybrid_df['Label'] == 0]

# Upsample goodware to match malware count
goodware_upsampled = resample(goodware, 
                               replace=True,
                               n_samples=len(malware),
                               random_state=42)

# Merge and shuffle
hybrid_df_balanced = pd.concat([malware, goodware_upsampled]).sample(frac=1, random_state=42)


# In[56]:


from sklearn.model_selection import cross_val_score

scores = cross_val_score(clf, X, y, cv=5, scoring='f1')
print("Cross-validated F1 scores:", scores)
print("Mean F1 score:", scores.mean())


# In[67]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.naive_bayes import GaussianNB
from sklearn.neighbors import KNeighborsClassifier

# Assume tuandromd_df and cicmaldroid_df are already loaded

# Separate features and labels
tuan_features = tuandromd_df.drop('Label', axis=1)
tuan_labels = tuandromd_df['Label']
cicm_features = cicmaldroid_df.drop('Label', axis=1)
cicm_labels = cicmaldroid_df['Label']

# Standardize features independently
scaler = StandardScaler()
tuan_scaled = scaler.fit_transform(tuan_features)
cicm_scaled = scaler.fit_transform(cicm_features)

tuan_df_scaled = pd.DataFrame(tuan_scaled, columns=tuan_features.columns)
tuan_df_scaled['Label'] = tuan_labels.values
cicm_df_scaled = pd.DataFrame(cicm_scaled, columns=cicm_features.columns)
cicm_df_scaled['Label'] = cicm_labels.values

# Normalize column names
tuan_df_scaled.columns = [col.lower() for col in tuan_df_scaled.columns]
cicm_df_scaled.columns = [col.lower() for col in cicm_df_scaled.columns]

# Align features
tuan_cols = set(tuan_df_scaled.columns) - {'label'}
cicm_cols = set(cicm_df_scaled.columns) - {'label'}
common_features = sorted(list(tuan_cols.intersection(cicm_cols)))

# Combine datasets on common features
tuan_df_final = tuan_df_scaled[common_features + ['label']]
cicm_df_final = cicm_df_scaled[common_features + ['label']]
hybrid_df = pd.concat([tuan_df_final, cicm_df_final], ignore_index=True)

# Split into X and y
X = hybrid_df.drop('label', axis=1)
y = hybrid_df['label']

# Train/test split
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, stratify=y, random_state=42
)

# Models to evaluate
models = {
    "Logistic Regression": LogisticRegression(max_iter=1000),
    "Decision Tree": DecisionTreeClassifier(),
    "Random Forest": RandomForestClassifier(n_estimators=100, random_state=42),
    "SVM": SVC(),
    "Naive Bayes": GaussianNB(),
    "KNN": KNeighborsClassifier()
}

# Store model accuracies
accuracies = {}

# Train and evaluate each model
for name, model in models.items():
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)
    acc = accuracy_score(y_test, y_pred)
    accuracies[name] = acc
    print(f"{name} Accuracy: {acc:.4f}")

# Plot model accuracies
plt.figure(figsize=(10, 6))
sns.barplot(x=list(accuracies.keys()), y=list(accuracies.values()), palette="viridis")
plt.ylabel("Accuracy")
plt.title("Model Accuracy Comparison")
plt.xticks(rotation=30)
plt.ylim(0, 1)
plt.grid(axis='y')
plt.tight_layout()
plt.show()


# In[58]:


import matplotlib.pyplot as plt
import seaborn as sns

# 1. Class distribution in hybrid dataset
plt.figure(figsize=(6, 4))
sns.countplot(data=hybrid_df, x='label', palette='viridis')
plt.title("Label Distribution in Hybrid Dataset")
plt.xlabel("Label (0 = Goodware, 1 = Malware)")
plt.ylabel("Count")
plt.tight_layout()
plt.show()

# 2. Histogram of selected features (first 6 features)
hybrid_df[common_features[:6]].hist(bins=30, figsize=(12, 8), layout=(2, 3), color='skyblue', edgecolor='black')
plt.suptitle("Histogram of Sample Features", fontsize=16)
plt.tight_layout()
plt.show()

# 3. Correlation heatmap
plt.figure(figsize=(10, 8))
corr = hybrid_df[common_features].corr()
sns.heatmap(corr, cmap='coolwarm', vmin=-1, vmax=1, linewidths=0.5)
plt.title("Feature Correlation Heatmap")
plt.tight_layout()
plt.show()

# 4. Feature importance from Random Forest
importances = clf.feature_importances_
feature_names = X.columns
importance_df = pd.DataFrame({'Feature': feature_names, 'Importance': importances})
importance_df = importance_df.sort_values(by='Importance', ascending=False)

# Plot top 20 features
plt.figure(figsize=(10, 6))
sns.barplot(data=importance_df.head(20), x='Importance', y='Feature', palette='magma')
plt.title("Top 20 Important Features (Random Forest)")
plt.xlabel("Importance Score")
plt.ylabel("Feature Name")
plt.tight_layout()
plt.show()


# In[59]:


from sklearn.metrics import ConfusionMatrixDisplay

# 5. Confusion matrix heatmap
ConfusionMatrixDisplay.from_estimator(clf, X_test, y_test, cmap='Blues')
plt.title("Confusion Matrix (Random Forest)")
plt.tight_layout()
plt.show()


# In[60]:


# TUANDROMD label distribution
plt.figure(figsize=(6, 4))
sns.countplot(data=tuan_df_final, x='label', palette='viridis')
plt.title("TUANDROMD Label Distribution")
plt.xlabel("Label (0 = Goodware, 1 = Malware)")
plt.ylabel("Count")
plt.tight_layout()
plt.show()

# CICMalDroid label distribution
plt.figure(figsize=(6, 4))
sns.countplot(data=cicm_df_final, x='label', palette='plasma')
plt.title("CICMalDroid Label Distribution")
plt.xlabel("Label (0 = Goodware, 1 = Malware)")
plt.ylabel("Count")
plt.tight_layout()
plt.show()


# In[61]:


# Sample histogram of first 6 common features
tuan_df_final[common_features[:6]].hist(bins=30, figsize=(12, 8), layout=(2, 3), color='skyblue', edgecolor='black')
plt.suptitle("Histogram of TUANDROMD Sample Features", fontsize=16)
plt.tight_layout()
plt.show()

cicm_df_final[common_features[:6]].hist(bins=30, figsize=(12, 8), layout=(2, 3), color='salmon', edgecolor='black')
plt.suptitle("Histogram of CICMalDroid Sample Features", fontsize=16)
plt.tight_layout()
plt.show()


# In[62]:


# Boxplot for class-wise comparison of 4 selected features
selected_features = common_features[:4]

for feature in selected_features:
    plt.figure(figsize=(6, 4))
    sns.boxplot(x='label', y=feature, data=hybrid_df, palette='Set2')
    plt.title(f"{feature} Distribution by Class (Hybrid Dataset)")
    plt.xlabel("Label (0 = Goodware, 1 = Malware)")
    plt.ylabel(feature)
    plt.tight_layout()
    plt.show()


# In[63]:


# TUANDROMD correlation
plt.figure(figsize=(10, 8))
sns.heatmap(tuan_df_final[common_features].corr(), cmap='coolwarm', linewidths=0.5)
plt.title("TUANDROMD Feature Correlation Heatmap")
plt.tight_layout()
plt.show()

# CICMalDroid correlation
plt.figure(figsize=(10, 8))
sns.heatmap(cicm_df_final[common_features].corr(), cmap='coolwarm', linewidths=0.5)
plt.title("CICMalDroid Feature Correlation Heatmap")
plt.tight_layout()
plt.show()


# In[64]:


# Use a few features for visual comparison
sample_features = common_features[:3] + ['label']

sns.pairplot(tuan_df_final[sample_features], hue='label', palette='husl', corner=True)
plt.suptitle("TUANDROMD Pair Plot by Label", y=1.02)
plt.show()

sns.pairplot(cicm_df_final[sample_features], hue='label', palette='husl', corner=True)
plt.suptitle("CICMalDroid Pair Plot by Label", y=1.02)
plt.show()


# In[65]:


from sklearn.decomposition import PCA

# Add source label to each dataset
tuan_df_final['source'] = 'TUANDROMD'
cicm_df_final['source'] = 'CICMalDroid'

# Combine the datasets
combined_df = pd.concat([tuan_df_final, cicm_df_final], ignore_index=True)

# Separate features and labels
X_combined = combined_df[common_features]
source_labels = combined_df['source']

# Apply PCA
pca = PCA(n_components=2, random_state=42)
X_pca = pca.fit_transform(X_combined)

# Prepare DataFrame for plotting
pca_df = pd.DataFrame(data=X_pca, columns=['PC1', 'PC2'])
pca_df['Source'] = source_labels.values

# Plot
plt.figure(figsize=(8, 6))
sns.scatterplot(data=pca_df, x='PC1', y='PC2', hue='Source', alpha=0.6, palette='Set1')
plt.title('PCA Projection: TUANDROMD vs CICMalDroid')
plt.xlabel('Principal Component 1')
plt.ylabel('Principal Component 2')
plt.legend(title='Dataset Source')
plt.tight_layout()
plt.show()


# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:




