import argparse
import os
import warnings
warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from joblib import dump

from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.feature_selection import SelectKBest, mutual_info_regression
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor

try:
    from xgboost import XGBRegressor
    HAS_XGB = True
except Exception:
    HAS_XGB = False

from utils import save_json, plot_confusion_bins

def infer_columns(df):
    target_col = "selling_price"
    possible_cat = ["name","fuel","seller_type","transmission","owner"]
    possible_num = ["year","km_driven","mileage","engine","max_power","seats"]
    cat_cols = [c for c in possible_cat if c in df.columns]
    num_cols = [c for c in possible_num if c in df.columns]
    if target_col not in df.columns:
        raise ValueError(f"Expected target column '{target_col}' not found.")
    return target_col, cat_cols, num_cols

def build_preprocessor(cat_cols, num_cols):
    categorical = Pipeline(steps=[
        ("imputer", SimpleImputer(strategy="most_frequent")),
        ("onehot", OneHotEncoder(handle_unknown="ignore"))
    ])
    numeric = Pipeline(steps=[
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler())
    ])
    return ColumnTransformer([
        ("cat", categorical, cat_cols),
        ("num", numeric, num_cols)
    ])

def train_models(X_train, y_train, preprocessor, kbest_k=None, random_state=42):
    models = {
        "LinearRegression": LinearRegression(),
        "RandomForest": RandomForestRegressor(
            n_estimators=400, random_state=random_state, n_jobs=-1
        ),
        "GradientBoosting": GradientBoostingRegressor(random_state=random_state),
    }
    if HAS_XGB:
        models["XGBRegressor"] = XGBRegressor(
            n_estimators=500, learning_rate=0.05, max_depth=6,
            subsample=0.8, colsample_bytree=0.8, random_state=random_state,
            reg_lambda=1.0, reg_alpha=0.0, tree_method="hist"
        )

    trained = {}
    for name, model in models.items():
        steps = [("pre", preprocessor)]
        if kbest_k is not None and kbest_k > 0:
            steps.append(("kbest", SelectKBest(score_func=mutual_info_regression, k=kbest_k)))
        steps.append(("reg", model))
        pipe = Pipeline(steps)
        pipe.fit(X_train, y_train)
        trained[name] = pipe
    return trained

def evaluate_models(models, X_test, y_test, reports_dir, bins=5):
    os.makedirs(reports_dir, exist_ok=True)
    metrics = {}
    for name, pipe in models.items():
        pred = pipe.predict(X_test)
        mae = mean_absolute_error(y_test, pred)
        rmse = mean_squared_error(y_test, pred, squared=False)
        r2 = r2_score(y_test, pred)
        metrics[name] = {"MAE": float(mae), "RMSE": float(rmse), "R2": float(r2)}

        plt.figure()
        plt.scatter(y_test, pred, alpha=0.5)
        plt.xlabel("Actual Price")
        plt.ylabel("Predicted Price")
        plt.title(f"Predicted vs Actual - {name}")
        plt.tight_layout()
        out1 = os.path.join(reports_dir, f"pred_vs_actual_{name}.png")
        plt.savefig(out1, dpi=140)
        plt.close()

        residuals = y_test - pred
        plt.figure()
        plt.scatter(pred, residuals, alpha=0.5)
        plt.axhline(0, linestyle="--")
        plt.xlabel("Predicted Price")
        plt.ylabel("Residual (Actual - Pred)")
        plt.title(f"Residuals - {name}")
        plt.tight_layout()
        out2 = os.path.join(reports_dir, f"residuals_{name}.png")
        plt.savefig(out2, dpi=140)
        plt.close()

        out3 = os.path.join(reports_dir, f"confusion_matrix_bins_{name}.png")
        plot_confusion_bins(y_test, pred, out3, n_bins=bins)

    save_json(metrics, os.path.join(reports_dir, "metrics.json"))
    return metrics

def main(args):
    df = pd.read_csv(args.data)
    target_col, cat_cols, num_cols = infer_columns(df)

    def to_numeric_safe(series):
        import pandas as pd
        return pd.to_numeric(series.astype(str).str.extract(r"([-+]?\d*\.?\d+)")[0], errors="coerce")

    for col in ["mileage","engine","max_power","seats"]:
        if col in df.columns:
            df[col] = to_numeric_safe(df[col])

    X = df[cat_cols + num_cols]
    y = df[target_col].astype(float)

    from sklearn.model_selection import train_test_split
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=args.test_size, random_state=args.seed
    )

    preprocessor = build_preprocessor(cat_cols, num_cols)
    kbest_k = args.kbest

    models = train_models(X_train, y_train, preprocessor, kbest_k=kbest_k, random_state=args.seed)
    metrics = evaluate_models(models, X_test, y_test, args.reports, bins=args.bins)

    best_name = min(metrics, key=lambda m: metrics[m]["RMSE"])
    best_model = models[best_name]

    os.makedirs(os.path.dirname(args.model_out), exist_ok=True)
    dump(best_model, args.model_out)

    print("Categorical:", cat_cols)
    print("Numerical:", num_cols)
    print(f"Saved best model: {best_name} -> {args.model_out}")
    print("Metrics:", metrics)

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", type=str, default="./data/car_data.csv")
    parser.add_argument("--model-out", type=str, default="./models/car_price_pipeline.pkl")
    parser.add_argument("--reports", type=str, default="./reports")
    parser.add_argument("--test-size", type=float, default=0.2)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--kbest", type=int, default=200, help="SelectKBest K (post-encoding). Set None to disable.")
    parser.add_argument("--bins", type=int, default=5, help="Price bins for confusion-matrix-style plot.")
    args = parser.parse_args()
    main(args)