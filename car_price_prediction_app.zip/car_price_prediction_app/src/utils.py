import json
import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay

def save_json(obj, path):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2)

def price_to_bins(y, n_bins=5, strategy="quantile"):
    """
    Convert continuous prices to bins for a classification-style view.
    strategy='quantile' gives roughly equal-sized bins.
    Returns: bin_indices (int array), bin_edges (array)
    """
    y = np.asarray(y).reshape(-1)
    if strategy == "quantile":
        quantiles = np.linspace(0, 1, n_bins + 1)
        edges = np.quantile(y, quantiles)
        edges = np.unique(edges)
        if len(edges) - 1 < n_bins:
            edges = np.linspace(y.min(), y.max(), n_bins + 1)
    else:
        edges = np.linspace(y.min(), y.max(), n_bins + 1)
    bins = np.digitize(y, edges[1:-1], right=False)
    return bins, edges

def plot_confusion_bins(y_true, y_pred, out_path, n_bins=5):
    y_true_bins, edges = price_to_bins(y_true, n_bins=n_bins)
    y_pred_bins, _ = price_to_bins(y_pred, n_bins=n_bins)
    cm = confusion_matrix(y_true_bins, y_pred_bins)
    disp = ConfusionMatrixDisplay(confusion_matrix=cm)
    fig = plt.figure()
    disp.plot(values_format="d")
    plt.title(f"Confusion Matrix (Price Bins = {n_bins})")
    plt.tight_layout()
    plt.savefig(out_path, dpi=140)
    plt.close(fig)